package OverLoading;
public class Addition {
	public int addition(int x, int y){
		return (x+y);
	}
	public int addition(int x, int y, int z){
		return (x+y+z);
	}
	public double addition(double d, double b){
		return (d+b);
	}
	public double addition(int a, float b){
		return (a+b);
	}
	public static void main(String args[]){
		System.out.println("Calling all method one by one for overloading..");
		Addition additionObject = new Addition();
		System.out.println("additon of int two argument ->"+additionObject.addition(10, 20)); 
		System.out.println("additon of int three argument ->"+additionObject.addition(10, 10, 10));
		System.out.println("additon of double two argument ->"+additionObject.addition(12.34, 34.12));
		System.out.println("additon of float two argument ->"+additionObject.addition(40.1, 40.12));
	}
}
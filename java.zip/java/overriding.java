rules of Overriding
1) The method is must be inheritance in sub class.
2) Parameters and return type should be same name as per super class.
3) we can change the return type in child class, otherwise it gives "incompatible with Overriding.addition(int, int)" error
4) we cannot reduce the access visibility of method in child class.
5) we can increase the access visibility of method in child class.
6) final, private and static can be override in java.


advantage of overriding
Child class (sub class) gives specific implementation to inheritance method without modifing parent class (base class).
Overriding always happened on run time only.


package Overriding;
class company {
		public int millage(){
			return (20);
	}}
	class Hero extends company{
		public int millage(){
			return (50);
		}}
	class Bajaj extends company{
		public int millage(){
			return (60);
		}}
	class TVS extends company{
		public int millage(){
			return (90);
	}}
public class Overriding{
	public static void main(String[] args) {
		Hero hero = new Hero();	Bajaj bajaj = new  Bajaj();	TVS tvs = new TVS();
		System.out.println("Hero ->"+hero.millage());
		System.out.println("Bajaj ->"+bajaj.millage());
		System.out.println("TVS ->"+tvs.millage());
	}}
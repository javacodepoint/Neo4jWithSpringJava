package OverLoading;
public class Addition {
	public int addition(int x, int y){
		return (x+y);
	}
	public int addition(int x, int y, int z){
		return (x+y+z);
	}
	public double addition(double d, double b){
		return (d+b);
	}
	public float addition(float a, float b){
		return (a+b);
	}
	public static void main(String args[]){
		System.out.println("Calling all method one by one for overloading..");
		Addition additionObject = new Addition();
		System.out.println("additon of int two argument ->"+additionObject.addition(10, 20)); 
		System.out.println("additon of int three argument ->"+additionObject.addition(10, 10, 10));
		System.out.println("additon of double two argument ->"+additionObject.addition(12.34, 34.12));
		System.out.println("additon of float two argument ->"+additionObject.addition(40.1, 40.12));
	}
}


output

Calling all method one by one for overloading..
additon of int two argument ->30
additon of int three argument ->30
additon of double two argument ->46.459999999999994
additon of float two argument ->80.22


Rules of overloading:
1)  types of parameters and order of parameters of both method should be different, either it is inheritance class or same class.
2)  change in return type and parameters must change, otherwise it show compile time error.

Advantage of OverLoading
1) It's increase the readibilty of java developers, no need to remember the same of function, only to take care of arguments only.
package Overriding;

class CoVariant {
	CoVariant getMessage() {
		return this;
	}
}

class CoVariantSub extends CoVariant {
	CoVariantSub getMessage() {
		return this;
	}

	void message() {
		System.out.println("this is example of covariant overriding..");
	}

	public static void main(String args[]) {
		new CoVariantSub().getMessage().message();
	}
}
